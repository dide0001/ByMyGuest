document.getElementById('cateringForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Tak for din henvendelse.');
    this.reset();
  });
